/* ===== SHARED CONTENT, HELPERS & VARIANTS for Dr. Julio Tatis ===== */

const CONTENT = {
  es: {
    nav: ['Servicios', 'El Doctor', 'Procedimientos', 'Contacto'],
    badge: 'Especialista en Columna · Panamá',
    h1Pre: 'Recupera',
    h1Italic: 'tu calidad de vida',
    h1Post: 'sin dolor',
    sub: 'Especialista en columna vertebral con formación internacional. Técnicas mínimamente invasivas y tratamiento personalizado para cada paciente.',
    ctaWhats: 'Agendar por WhatsApp',
    ctaCall: 'Llamar a la clínica',
    services: [
      { name: 'Hernia Discal', desc: 'Diagnóstico preciso y tratamiento conservador o quirúrgico mínimamente invasivo.' },
      { name: 'Cirugía de Columna', desc: 'Procedimientos avanzados con técnicas de última generación y recuperación rápida.' },
      { name: 'Dolor Lumbar Crónico', desc: 'Plan integral con terapias conservadoras antes de considerar cirugía.' },
      { name: 'Estenosis Espinal', desc: 'Liberación de presión nerviosa para restaurar movilidad y calidad de vida.' },
      { name: 'Cervicalgia', desc: 'Diagnóstico de dolor cervical, hernias y tratamientos personalizados.' },
      { name: 'Escoliosis', desc: 'Evaluación y manejo integral de desviaciones de la columna vertebral.' },
    ],
    aboutTitle: 'Formación internacional al servicio de tu salud',
    aboutBody: 'Especialista en patología y cirugía de columna con maestría internacional en cirugía espinal. Más de una década dedicada a devolverle a sus pacientes la libertad de moverse sin dolor.',
    credentials: ['Especialidad en Cirugía de Columna', 'Maestría Internacional en Cirugía Espinal', 'Más de 1,500 pacientes atendidos', 'Miembro asociaciones médicas internacionales'],
    statsLabels: ['Pacientes', 'Años de experiencia', 'Tasa de éxito', 'Recuperación rápida'],
    procTitle: 'Cómo trabajamos',
    procSub: 'Un proceso transparente diseñado para tu tranquilidad',
    proc: [
      { num: '01', title: 'Consulta inicial', desc: 'Evaluación completa de historial, estudios y síntomas. Sin compromiso.' },
      { num: '02', title: 'Diagnóstico personalizado', desc: 'Análisis con imagenología avanzada para entender tu condición exacta.' },
      { num: '03', title: 'Plan de tratamiento', desc: 'Opciones conservadoras primero. Cirugía solo cuando es realmente necesaria.' },
      { num: '04', title: 'Seguimiento', desc: 'Acompañamiento continuo durante toda tu recuperación.' },
    ],
    testimonialTitle: 'Pacientes que recuperaron su vida',
    testimonials: [
      { text: 'Después de años de dolor crónico, el Dr. Julio me ofreció una solución mínimamente invasiva. Hoy vuelvo a caminar sin dolor.', name: 'Carlos M.', context: 'Hernia lumbar · 58 años' },
      { text: 'La calidez humana del doctor y su equipo hace toda la diferencia. Te explica todo con claridad y nunca te presiona.', name: 'Isabel R.', context: 'Cervicalgia crónica · 45 años' },
      { text: 'Recuperación rápida y resultados extraordinarios. La cirugía cambió mi vida por completo.', name: 'Luis A.', context: 'Estenosis espinal · 64 años' },
    ],
    contactTitle: 'Agenda tu consulta',
    contactSub: 'Respondemos por WhatsApp en menos de 1 hora hábil',
    formName: 'Nombre completo',
    formPhone: 'Teléfono',
    formReason: '¿Qué te trae por aquí?',
    formReasonOpts: ['Dolor lumbar', 'Dolor cervical', 'Hernia discal', 'Segunda opinión', 'Otro'],
    formMsg: 'Cuéntanos brevemente',
    formSubmit: 'Enviar por WhatsApp',
    footerHours: 'Lun – Vie: 8:00 AM – 5:00 PM',
    footerLoc: 'Ciudad de Panamá · COPAC',
    riskFree: '✓ Consulta confidencial · ✓ Sin compromiso · ✓ Atención bilingüe',
  },
  en: {
    nav: ['Services', 'About', 'Process', 'Contact'],
    badge: 'Spine Specialist · Panama',
    h1Pre: 'Reclaim',
    h1Italic: 'your quality of life',
    h1Post: 'pain-free',
    sub: 'Internationally trained spine specialist. Minimally invasive techniques and personalized care for every patient.',
    ctaWhats: 'Book on WhatsApp',
    ctaCall: 'Call the clinic',
    services: [
      { name: 'Herniated Disc', desc: 'Accurate diagnosis with conservative or minimally invasive surgical treatment.' },
      { name: 'Spine Surgery', desc: 'Advanced procedures using cutting-edge techniques and rapid recovery.' },
      { name: 'Chronic Low Back Pain', desc: 'Comprehensive plan with conservative therapies before considering surgery.' },
      { name: 'Spinal Stenosis', desc: 'Nerve decompression to restore mobility and quality of life.' },
      { name: 'Neck Pain', desc: 'Diagnosis of cervical pain, herniations and personalized treatment.' },
      { name: 'Scoliosis', desc: 'Evaluation and comprehensive management of spinal deviations.' },
    ],
    aboutTitle: 'International training in service of your health',
    aboutBody: 'Specialist in spine pathology and surgery with an international master\'s degree in spinal surgery. Over a decade dedicated to giving patients back the freedom to move pain-free.',
    credentials: ['Specialty in Spine Surgery', 'International Master\'s in Spinal Surgery', 'Over 1,500 patients treated', 'Member of international medical associations'],
    statsLabels: ['Patients', 'Years experience', 'Success rate', 'Fast recovery'],
    procTitle: 'How we work',
    procSub: 'A transparent process designed for your peace of mind',
    proc: [
      { num: '01', title: 'Initial consult', desc: 'Full review of history, imaging, and symptoms. No commitment required.' },
      { num: '02', title: 'Personalized diagnosis', desc: 'Advanced imaging analysis to understand your exact condition.' },
      { num: '03', title: 'Treatment plan', desc: 'Conservative options first. Surgery only when truly necessary.' },
      { num: '04', title: 'Follow-up', desc: 'Continuous support throughout your recovery.' },
    ],
    testimonialTitle: 'Patients who reclaimed their lives',
    testimonials: [
      { text: 'After years of chronic pain, Dr. Julio offered me a minimally invasive solution. Today I walk pain-free again.', name: 'Carlos M.', context: 'Lumbar hernia · 58 yrs' },
      { text: 'The doctor\'s warmth and his team make all the difference. He explains everything clearly and never pressures you.', name: 'Isabel R.', context: 'Chronic neck pain · 45 yrs' },
      { text: 'Fast recovery and extraordinary results. Surgery changed my life completely.', name: 'Luis A.', context: 'Spinal stenosis · 64 yrs' },
    ],
    contactTitle: 'Book your consultation',
    contactSub: 'We reply on WhatsApp within 1 business hour',
    formName: 'Full name',
    formPhone: 'Phone',
    formReason: 'What brings you here?',
    formReasonOpts: ['Low back pain', 'Neck pain', 'Herniated disc', 'Second opinion', 'Other'],
    formMsg: 'Tell us briefly',
    formSubmit: 'Send via WhatsApp',
    footerHours: 'Mon – Fri: 8:00 AM – 5:00 PM',
    footerLoc: 'Panama City · COPAC',
    riskFree: '✓ Confidential consult · ✓ No commitment · ✓ Bilingual support',
  }
};

/* ===== HELPERS ===== */
const SpineIcon = ({ size = 200, color = '#1a3a6e', opacity = 1 }) => (
  <svg width={size} height={size * 2.5} viewBox="0 0 80 200" style={{ opacity }}>
    {Array.from({ length: 14 }).map((_, i) => {
      const y = 12 + i * 13;
      const w = 28 + Math.sin(i * 0.4) * 6;
      return (
        <g key={i}>
          <rect x={40 - w/2} y={y} width={w} height="8" rx="2" fill={color} opacity={0.85} />
          <line x1="40" y1={y + 9} x2="40" y2={y + 12} stroke={color} strokeWidth="1.5" opacity={0.4} />
        </g>
      );
    })}
  </svg>
);

const DoctorPhoto = ({ w, h, label = 'Foto Dr. Julio Tatis', variant = 'portrait' }) => {
  const src = variant === 'spine' ? 'img/dr-spine-model.png' : 'img/dr-portrait.png';
  return (
    <div style={{ width: w, height: h, overflow: 'hidden', position: 'relative', background: '#e0e7f0' }}>
      <img src={src} alt={label} style={{ width: '100%', height: '100%', objectFit: 'cover', objectPosition: 'center top', display: 'block' }} />
    </div>
  );
};

const ClinicPhoto = ({ w, h, label = 'Instalaciones COPAC', variant = 'spine' }) => {
  const src = variant === 'portrait' ? 'img/dr-portrait.png' : 'img/dr-spine-model.png';
  return (
    <div style={{ width: w, height: h, overflow: 'hidden', position: 'relative', background: '#e0e7f0' }}>
      <img src={src} alt={label} style={{ width: '100%', height: '100%', objectFit: 'cover', objectPosition: 'center 20%', display: 'block' }} />
    </div>
  );
};

/* ===== LANG TOGGLE ===== */
const LangToggle = ({ lang, setLang }) => (
  <div style={{
    position: 'fixed',
    top: '12px',
    left: '12px',
    zIndex: 1000,
    display: 'flex',
    background: 'rgba(255,255,255,0.95)',
    borderRadius: '999px',
    padding: '3px',
    border: '1px solid rgba(20,40,80,0.1)',
    boxShadow: '0 4px 12px rgba(20,40,80,0.08)',
  }}>
    {['es', 'en'].map(l => (
      <button
        key={l}
        onClick={() => setLang(l)}
        style={{
          padding: '5px 12px',
          fontSize: '11px',
          fontWeight: 600,
          letterSpacing: '0.1em',
          textTransform: 'uppercase',
          background: lang === l ? '#1a3a6e' : 'transparent',
          color: lang === l ? '#fff' : '#5a7090',
          border: 'none',
          borderRadius: '999px',
          cursor: 'pointer',
        }}
      >{l}</button>
    ))}
  </div>
);

/* ===== CONTACT FORM ===== */
const ContactForm = ({ lang, dark = false, accent = '#1a3a6e' }) => {
  const t = CONTENT[lang];
  const [reason, setReason] = React.useState(t.formReasonOpts[0]);
  const inputBase = {
    width: '100%',
    padding: '14px 16px',
    fontSize: '14px',
    border: dark ? '1px solid rgba(168,184,212,0.25)' : '1px solid #d4dce8',
    background: dark ? 'rgba(255,255,255,0.04)' : '#fff',
    color: dark ? '#fff' : '#0a1830',
    outline: 'none',
    borderRadius: '0',
  };
  const labelBase = {
    fontSize: '10px',
    letterSpacing: '0.18em',
    textTransform: 'uppercase',
    color: dark ? '#a8b8d4' : '#5a7090',
    marginBottom: '8px',
    display: 'block',
    fontWeight: 600,
  };
  return (
    <form onSubmit={e => e.preventDefault()} style={{ background: dark ? 'rgba(255,255,255,0.03)' : '#fff', padding: '36px', border: dark ? '1px solid rgba(168,184,212,0.15)' : '1px solid #d4dce8' }}>
      <div style={{ marginBottom: '20px' }}>
        <label style={labelBase}>{t.formName}</label>
        <input style={inputBase} placeholder={lang === 'es' ? 'María Pérez' : 'Maria Perez'} />
      </div>
      <div style={{ marginBottom: '20px' }}>
        <label style={labelBase}>{t.formPhone}</label>
        <input style={inputBase} placeholder="+507 ..." />
      </div>
      <div style={{ marginBottom: '20px' }}>
        <label style={labelBase}>{t.formReason}</label>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '6px' }}>
          {t.formReasonOpts.map(opt => (
            <button
              key={opt}
              type="button"
              onClick={() => setReason(opt)}
              style={{
                padding: '10px 8px',
                fontSize: '11px',
                border: '1px solid ' + (reason === opt ? accent : (dark ? 'rgba(168,184,212,0.25)' : '#d4dce8')),
                background: reason === opt ? (dark ? 'rgba(90,138,204,0.15)' : '#eaf0fa') : 'transparent',
                color: reason === opt ? (dark ? '#fff' : accent) : (dark ? '#a8b8d4' : '#5a7090'),
                cursor: 'pointer',
                fontWeight: reason === opt ? 600 : 400,
                letterSpacing: '0.04em',
              }}
            >{opt}</button>
          ))}
        </div>
      </div>
      <div style={{ marginBottom: '24px' }}>
        <label style={labelBase}>{t.formMsg}</label>
        <textarea rows="3" style={{ ...inputBase, resize: 'vertical' }} placeholder={lang === 'es' ? 'Hace 3 meses tengo dolor lumbar...' : 'I\'ve had low back pain for 3 months...'} />
      </div>
      <button type="submit" style={{
        width: '100%',
        padding: '16px',
        background: '#25D366',
        border: 'none',
        color: '#fff',
        fontSize: '14px',
        fontWeight: 600,
        cursor: 'pointer',
        display: 'flex', justifyContent: 'center', alignItems: 'center', gap: '10px',
      }}>
        <svg width="16" height="16" viewBox="0 0 24 24" fill="#fff"><path d="M17.6 6.3A7.85 7.85 0 0 0 12 4a7.94 7.94 0 0 0-7.9 7.9 7.83 7.83 0 0 0 1 3.9L4 20l4.3-1.1a7.93 7.93 0 0 0 3.7.9 7.94 7.94 0 0 0 7.9-7.9 7.85 7.85 0 0 0-2.3-5.6Z"/></svg>
        {t.formSubmit}
      </button>
      <div style={{ fontSize: '11px', color: dark ? '#7a8aa8' : '#8a98b0', textAlign: 'center', marginTop: '12px', letterSpacing: '0.04em' }}>
        🔒 {lang === 'es' ? 'Tus datos son confidenciales · Sin spam' : 'Your data is confidential · No spam'}
      </div>
    </form>
  );
};

/* Export all to window for cross-script access */
Object.assign(window, { CONTENT, SpineIcon, DoctorPhoto, ClinicPhoto, ContactForm, LangToggle });
