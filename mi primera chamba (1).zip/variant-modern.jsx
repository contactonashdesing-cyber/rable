/* ===== VARIANT 2: MODERN SPINE ===== */
const ModernSpine = ({ lang }) => {
  const t = CONTENT[lang];
  return (
    <div style={{ width: '100%', minHeight: '1450px', background: '#fcfcfd', color: '#0a1220', fontFamily: "'Manrope', sans-serif", position: 'relative', overflow: 'hidden' }}>
      <nav style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '20px 56px', background: 'rgba(252,252,253,0.95)', backdropFilter: 'blur(12px)', position: 'sticky', top: 0, zIndex: 100, borderBottom: '1px solid rgba(20,40,80,0.08)' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
          <SpineIcon size={20} color="#1a3a6e" />
          <div>
            <div style={{ fontSize: '15px', color: '#0a1220', fontWeight: 700, letterSpacing: '-0.01em' }}>JULIO·TATIS</div>
            <div style={{ fontSize: '9px', letterSpacing: '0.22em', color: '#5a7090', textTransform: 'uppercase' }}>{lang === 'es' ? 'Columna · Panamá' : 'Spine · Panama'}</div>
          </div>
        </div>
        <div style={{ display: 'flex', gap: '8px', padding: '4px', background: '#eef2f8', borderRadius: '999px' }}>
          {t.nav.map(item => <span key={item} style={{ fontSize: '13px', color: '#3a4a6a', cursor: 'pointer', padding: '8px 16px', borderRadius: '999px', fontWeight: 500 }}>{item}</span>)}
        </div>
        <button style={{ padding: '12px 22px', background: '#25D366', border: 'none', color: '#fff', fontSize: '13px', fontWeight: 600, cursor: 'pointer', borderRadius: '999px', display: 'flex', alignItems: 'center', gap: '8px' }}>
          <svg width="14" height="14" viewBox="0 0 24 24" fill="#fff"><path d="M17.6 6.3A7.85 7.85 0 0 0 12 4a7.94 7.94 0 0 0-7.9 7.9 7.83 7.83 0 0 0 1 3.9L4 20l4.3-1.1a7.93 7.93 0 0 0 3.7.9 7.94 7.94 0 0 0 7.9-7.9 7.85 7.85 0 0 0-2.3-5.6Z"/></svg>
          WhatsApp
        </button>
      </nav>

      <div style={{ position: 'relative', minHeight: '720px', overflow: 'hidden' }}>
        <div style={{ position: 'absolute', inset: 0, background: 'radial-gradient(ellipse at 80% 20%, rgba(90,138,204,0.12) 0%, transparent 50%), radial-gradient(ellipse at 20% 80%, rgba(180,200,235,0.18) 0%, transparent 50%)' }} />
        <div style={{ position: 'absolute', top: '60px', left: '50%', transform: 'translateX(-50%)', zIndex: 1, opacity: 0.85 }}>
          <SpineIcon size={180} color="#1a3a6e" opacity={0.18} />
        </div>
        <div style={{ position: 'absolute', top: '180px', left: '32%', display: 'flex', alignItems: 'center', gap: '12px' }}>
          <div style={{ width: '60px', height: '1px', background: '#1a3a6e' }} />
          <div style={{ background: '#fff', border: '1px solid #1a3a6e', padding: '6px 12px', fontSize: '11px', color: '#1a3a6e', fontWeight: 600, letterSpacing: '0.05em' }}>C1–C7 · {lang === 'es' ? 'Cervical' : 'Cervical'}</div>
        </div>
        <div style={{ position: 'absolute', top: '380px', right: '30%', display: 'flex', alignItems: 'center', gap: '12px' }}>
          <div style={{ background: '#fff', border: '1px solid #1a3a6e', padding: '6px 12px', fontSize: '11px', color: '#1a3a6e', fontWeight: 600, letterSpacing: '0.05em' }}>L1–L5 · {lang === 'es' ? 'Lumbar' : 'Lumbar'}</div>
          <div style={{ width: '60px', height: '1px', background: '#1a3a6e' }} />
        </div>

        <div style={{ position: 'relative', zIndex: 5, padding: '100px 56px 80px', maxWidth: '640px' }}>
          <div style={{ display: 'inline-flex', alignItems: 'center', gap: '8px', background: '#fff', border: '1px solid rgba(20,40,80,0.1)', padding: '8px 16px', borderRadius: '999px', fontSize: '12px', color: '#1a3a6e', fontWeight: 600, marginBottom: '32px' }}>
            <span style={{ width: '6px', height: '6px', borderRadius: '50%', background: '#25D366' }}></span>
            {lang === 'es' ? 'Aceptando nuevos pacientes' : 'Accepting new patients'}
          </div>
          <h1 style={{ fontFamily: "'Manrope', sans-serif", fontSize: '88px', lineHeight: 0.93, fontWeight: 700, color: '#0a1220', letterSpacing: '-0.04em', marginBottom: '24px' }}>
            {lang === 'es' ? 'Vive sin' : 'Live'}<br />
            <span style={{ color: '#1a3a6e', fontFamily: "'Instrument Serif', serif", fontStyle: 'italic', fontWeight: 400, fontSize: '92px', letterSpacing: '-0.02em' }}>{lang === 'es' ? 'dolor de espalda.' : 'pain-free.'}</span>
          </h1>
          <p style={{ fontSize: '18px', lineHeight: 1.55, color: '#3a4a6a', maxWidth: '480px', fontWeight: 400, marginBottom: '36px' }}>
            {lang === 'es' ? 'Especialista en cirugía mínimamente invasiva de columna. Diagnóstico preciso, tratamiento personalizado, recuperación rápida.' : 'Specialist in minimally invasive spine surgery. Precise diagnosis, personalized treatment, fast recovery.'}
          </p>
          <div style={{ display: 'flex', gap: '12px', alignItems: 'center', marginBottom: '40px' }}>
            <button style={{ padding: '18px 32px', background: '#0a1220', border: 'none', color: '#fff', fontSize: '15px', fontWeight: 600, cursor: 'pointer', borderRadius: '999px', display: 'flex', alignItems: 'center', gap: '10px' }}>{t.ctaWhats}<span>→</span></button>
            <button style={{ padding: '18px 24px', background: 'transparent', border: 'none', color: '#1a3a6e', fontSize: '15px', fontWeight: 600, cursor: 'pointer', display: 'flex', alignItems: 'center', gap: '8px' }}>
              <span style={{ width: '32px', height: '32px', borderRadius: '50%', border: '1px solid #1a3a6e', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>▶</span>
              {lang === 'es' ? 'Ver explicación' : 'Watch explainer'}
            </button>
          </div>

          <div style={{ background: '#fff', border: '1px solid rgba(20,40,80,0.08)', borderRadius: '20px', padding: '24px', boxShadow: '0 20px 50px -20px rgba(20,40,80,0.15)' }}>
            <div style={{ fontSize: '11px', letterSpacing: '0.18em', color: '#5a7090', textTransform: 'uppercase', marginBottom: '12px', fontWeight: 600 }}>{lang === 'es' ? '¿Cuál es tu síntoma?' : 'What\'s your symptom?'}</div>
            <div style={{ display: 'flex', gap: '8px', flexWrap: 'wrap' }}>
              {t.formReasonOpts.map((opt, i) => (
                <button key={opt} style={{ padding: '10px 18px', background: i === 0 ? '#1a3a6e' : '#f4f6fa', color: i === 0 ? '#fff' : '#3a4a6a', border: 'none', borderRadius: '999px', fontSize: '13px', fontWeight: 500, cursor: 'pointer' }}>{opt}</button>
              ))}
            </div>
          </div>
        </div>

        <div style={{ position: 'absolute', right: '56px', bottom: '60px', width: '300px', background: '#fff', borderRadius: '24px', padding: '20px', boxShadow: '0 30px 60px -20px rgba(20,40,80,0.25)', zIndex: 5 }}>
          <div style={{ borderRadius: '16px', overflow: 'hidden', marginBottom: '16px' }}>
            <DoctorPhoto w={260} h={200} label="Dr. Julio Tatis" />
          </div>
          <div style={{ fontSize: '17px', color: '#0a1220', fontWeight: 700, letterSpacing: '-0.01em' }}>Dr. Guillermo Julio Tatis</div>
          <div style={{ fontSize: '12px', color: '#5a7090', marginTop: '4px', marginBottom: '14px' }}>{lang === 'es' ? 'Cirujano de Columna · 15 años' : 'Spine Surgeon · 15 years'}</div>
          <div style={{ display: 'flex', gap: '6px' }}>
            {[1,2,3,4,5].map(s => <span key={s} style={{ color: '#f5b400', fontSize: '14px' }}>★</span>)}
            <span style={{ fontSize: '12px', color: '#3a4a6a', fontWeight: 600, marginLeft: '4px' }}>4.9 · 320 {lang === 'es' ? 'reseñas' : 'reviews'}</span>
          </div>
        </div>
      </div>

      <div style={{ padding: '80px 56px', background: '#fff' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', marginBottom: '40px' }}>
          <div>
            <div style={{ fontSize: '11px', letterSpacing: '0.22em', color: '#1a3a6e', textTransform: 'uppercase', marginBottom: '12px', fontWeight: 600 }}>{lang === 'es' ? 'Tratamientos' : 'Treatments'}</div>
            <h2 style={{ fontFamily: "'Manrope', sans-serif", fontSize: '48px', color: '#0a1220', fontWeight: 700, letterSpacing: '-0.03em', lineHeight: 1.05 }}>{lang === 'es' ? 'Soluciones para cada' : 'Solutions for every'}<br /><span style={{ fontFamily: "'Instrument Serif', serif", fontStyle: 'italic', fontWeight: 400, color: '#1a3a6e' }}>{lang === 'es' ? 'condición.' : 'condition.'}</span></h2>
          </div>
          <span style={{ fontSize: '13px', color: '#1a3a6e', cursor: 'pointer', fontWeight: 600 }}>{lang === 'es' ? 'Ver todos →' : 'See all →'}</span>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '16px' }}>
          {t.services.map((s, i) => (
            <div key={s.name} style={{ padding: '28px', background: i === 0 ? '#0a1220' : '#f4f6fa', color: i === 0 ? '#fff' : '#0a1220', borderRadius: '20px', cursor: 'pointer', position: 'relative', minHeight: '180px', display: 'flex', flexDirection: 'column', justifyContent: 'space-between' }}>
              <div>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '20px' }}>
                  <SpineIcon size={26} color={i === 0 ? '#5a8acc' : '#1a3a6e'} opacity={0.7} />
                  <span style={{ fontSize: '11px', color: i === 0 ? '#a8b8d4' : '#8a98b0', letterSpacing: '0.05em' }}>0{i+1}</span>
                </div>
                <div style={{ fontSize: '20px', fontWeight: 700, marginBottom: '8px', letterSpacing: '-0.01em' }}>{s.name}</div>
                <div style={{ fontSize: '13px', color: i === 0 ? '#a8b8d4' : '#5a7090', lineHeight: 1.5 }}>{s.desc}</div>
              </div>
              <div style={{ marginTop: '20px', fontSize: '12px', color: i === 0 ? '#5a8acc' : '#1a3a6e', fontWeight: 600, letterSpacing: '0.05em' }}>{lang === 'es' ? 'CONOCER MÁS →' : 'LEARN MORE →'}</div>
            </div>
          ))}
        </div>
      </div>

      <div style={{ padding: '64px 56px', background: 'linear-gradient(135deg, #0a1220 0%, #1a3a6e 100%)', color: '#fff' }}>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '32px' }}>
          {[
            { num: '1,500+', label: t.statsLabels[0], icon: '👥' },
            { num: '15+', label: t.statsLabels[1], icon: '🎓' },
            { num: '98%', label: t.statsLabels[2], icon: '✓' },
            { num: '< 1h', label: lang === 'es' ? 'Respuesta WhatsApp' : 'WhatsApp reply', icon: '⚡' },
          ].map(s => (
            <div key={s.label}>
              <div style={{ fontSize: '24px', marginBottom: '12px' }}>{s.icon}</div>
              <div style={{ fontFamily: "'Instrument Serif', serif", fontSize: '54px', fontWeight: 400, color: '#fff', lineHeight: 1, letterSpacing: '-0.02em' }}>{s.num}</div>
              <div style={{ fontSize: '12px', color: '#a8b8d4', letterSpacing: '0.1em', marginTop: '6px', textTransform: 'uppercase' }}>{s.label}</div>
            </div>
          ))}
        </div>
      </div>

      <div style={{ padding: '80px 56px', background: '#fcfcfd', display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '56px' }}>
        <div>
          <div style={{ fontSize: '11px', letterSpacing: '0.22em', color: '#1a3a6e', textTransform: 'uppercase', marginBottom: '12px', fontWeight: 600 }}>{lang === 'es' ? 'Testimonios' : 'Testimonials'}</div>
          <h2 style={{ fontFamily: "'Manrope', sans-serif", fontSize: '40px', color: '#0a1220', fontWeight: 700, letterSpacing: '-0.03em', lineHeight: 1.05, marginBottom: '32px' }}>{t.testimonialTitle}</h2>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
            {t.testimonials.map(tt => (
              <div key={tt.name} style={{ background: '#fff', padding: '24px', borderRadius: '16px', border: '1px solid rgba(20,40,80,0.08)' }}>
                <div style={{ display: 'flex', gap: '4px', marginBottom: '12px' }}>
                  {[1,2,3,4,5].map(s => <span key={s} style={{ color: '#f5b400', fontSize: '13px' }}>★</span>)}
                </div>
                <p style={{ fontSize: '15px', color: '#0a1220', lineHeight: 1.55, marginBottom: '14px' }}>"{tt.text}"</p>
                <div style={{ fontSize: '13px', color: '#0a1220', fontWeight: 700 }}>{tt.name}</div>
                <div style={{ fontSize: '12px', color: '#5a7090', marginTop: '2px' }}>{tt.context}</div>
              </div>
            ))}
          </div>
        </div>
        <div style={{ position: 'sticky', top: '100px', alignSelf: 'flex-start' }}>
          <div style={{ fontSize: '11px', letterSpacing: '0.22em', color: '#1a3a6e', textTransform: 'uppercase', marginBottom: '12px', fontWeight: 600 }}>{lang === 'es' ? 'Contacto' : 'Contact'}</div>
          <h2 style={{ fontFamily: "'Manrope', sans-serif", fontSize: '40px', color: '#0a1220', fontWeight: 700, letterSpacing: '-0.03em', lineHeight: 1.05, marginBottom: '24px' }}>{t.contactTitle}</h2>
          <ContactForm lang={lang} />
        </div>
      </div>
    </div>
  );
};

window.ModernSpine = ModernSpine;
