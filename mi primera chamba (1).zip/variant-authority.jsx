/* ===== VARIANT 1: CLINICAL AUTHORITY ===== */
/* Editorial medical, serif, structured grid, deep navy + ivory */
const ClinicalAuthority = ({ lang }) => {
  const t = CONTENT[lang];
  return (
    <div style={{
      width: '100%', minHeight: '1450px',
      background: '#fafbfc',
      color: '#0a1830',
      fontFamily: "'DM Sans', sans-serif",
      position: 'relative',
    }}>
      <div style={{ background: '#0a1830', color: '#a8b8d4', padding: '8px 56px', display: 'flex', justifyContent: 'space-between', fontSize: '11px', letterSpacing: '0.08em' }}>
        <span>📍 COPAC · Ciudad de Panamá</span>
        <div style={{ display: 'flex', gap: '24px' }}>
          <span>📞 +507 6000-0000</span>
          <span>{t.footerHours}</span>
          <span style={{ color: '#fff' }}>ES · EN</span>
        </div>
      </div>

      <nav style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '24px 56px', background: '#fff', borderBottom: '1px solid #e4e9f0' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '14px' }}>
          <svg width="40" height="40" viewBox="0 0 40 40">
            <rect x="2" y="2" width="36" height="36" fill="none" stroke="#0a1830" strokeWidth="1.5" />
            <text x="20" y="26" textAnchor="middle" fontFamily="serif" fontSize="18" fill="#0a1830" fontStyle="italic">G</text>
          </svg>
          <div>
            <div style={{ fontFamily: "'Fraunces', serif", fontSize: '18px', color: '#0a1830', fontWeight: 500, letterSpacing: '-0.01em' }}>Dr. Guillermo Julio Tatis</div>
            <div style={{ fontSize: '10px', letterSpacing: '0.18em', color: '#5a7090', textTransform: 'uppercase', marginTop: '1px' }}>{lang === 'es' ? 'Especialista en Columna · Panamá' : 'Spine Specialist · Panama'}</div>
          </div>
        </div>
        <div style={{ display: 'flex', gap: '32px', alignItems: 'center' }}>
          {t.nav.map(item => <span key={item} style={{ fontSize: '13px', color: '#3a4a6a', cursor: 'pointer' }}>{item}</span>)}
          <button style={{ padding: '11px 22px', background: '#1a3a6e', border: 'none', color: '#fff', fontSize: '12px', letterSpacing: '0.06em', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: '8px' }}>
            <svg width="14" height="14" viewBox="0 0 24 24" fill="#fff"><path d="M17.6 6.3A7.85 7.85 0 0 0 12 4a7.94 7.94 0 0 0-7.9 7.9 7.83 7.83 0 0 0 1 3.9L4 20l4.3-1.1a7.93 7.93 0 0 0 3.7.9 7.94 7.94 0 0 0 7.9-7.9 7.85 7.85 0 0 0-2.3-5.6Zm-5.6 12.1a6.5 6.5 0 0 1-3.3-.9l-.2-.1-2.5.6.7-2.4-.2-.2a6.55 6.55 0 1 1 12.1-3.5 6.55 6.55 0 0 1-6.6 6.5Z"/></svg>
            WhatsApp
          </button>
        </div>
      </nav>

      <div style={{ display: 'grid', gridTemplateColumns: '1.1fr 1fr', minHeight: '600px' }}>
        <div style={{ padding: '80px 56px 60px', display: 'flex', flexDirection: 'column', justifyContent: 'center', gap: '28px', position: 'relative' }}>
          <div style={{ position: 'absolute', top: '40px', right: '40px', fontFamily: "'Fraunces', serif", fontSize: '14px', color: '#a8b8d4', letterSpacing: '0.2em' }}>EST. 2010</div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
            <div style={{ width: '48px', height: '1px', background: '#1a3a6e' }} />
            <span style={{ fontSize: '11px', letterSpacing: '0.25em', color: '#1a3a6e', textTransform: 'uppercase', fontWeight: 500 }}>{t.badge}</span>
          </div>
          <h1 style={{ fontFamily: "'Fraunces', serif", fontSize: '76px', lineHeight: 0.98, fontWeight: 400, color: '#0a1830', letterSpacing: '-0.025em' }}>
            {t.h1Pre}<br />
            <em style={{ fontStyle: 'italic', fontWeight: 300, color: '#1a3a6e' }}>{t.h1Italic}</em><br />
            {t.h1Post}.
          </h1>
          <p style={{ fontSize: '17px', lineHeight: 1.65, color: '#3a4a6a', maxWidth: '480px', fontWeight: 400 }}>{t.sub}</p>
          <div style={{ display: 'flex', gap: '14px', marginTop: '8px' }}>
            <button style={{ padding: '17px 32px', background: '#25D366', border: 'none', color: '#fff', fontSize: '14px', fontWeight: 600, cursor: 'pointer', display: 'flex', alignItems: 'center', gap: '10px', boxShadow: '0 4px 14px rgba(37,211,102,0.25)' }}>
              <svg width="18" height="18" viewBox="0 0 24 24" fill="#fff"><path d="M17.6 6.3A7.85 7.85 0 0 0 12 4a7.94 7.94 0 0 0-7.9 7.9 7.83 7.83 0 0 0 1 3.9L4 20l4.3-1.1a7.93 7.93 0 0 0 3.7.9 7.94 7.94 0 0 0 7.9-7.9 7.85 7.85 0 0 0-2.3-5.6Z"/></svg>
              {t.ctaWhats}
            </button>
            <button style={{ padding: '17px 28px', background: '#fff', border: '1.5px solid #0a1830', color: '#0a1830', fontSize: '14px', fontWeight: 500, cursor: 'pointer' }}>{t.ctaCall} →</button>
          </div>
          <div style={{ marginTop: '8px', fontSize: '12px', color: '#5a7090', letterSpacing: '0.04em' }}>{t.riskFree}</div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '24px', marginTop: '32px', paddingTop: '32px', borderTop: '1px solid #d4dce8' }}>
            {[['1,500+', t.statsLabels[0]], ['15+', t.statsLabels[1]], ['98%', t.statsLabels[2]], ['Min.', t.statsLabels[3]]].map(([num, label]) => (
              <div key={label}>
                <div style={{ fontFamily: "'Fraunces', serif", fontSize: '36px', color: '#1a3a6e', fontWeight: 400, lineHeight: 1, letterSpacing: '-0.02em' }}>{num}</div>
                <div style={{ fontSize: '11px', color: '#5a7090', letterSpacing: '0.12em', marginTop: '6px', textTransform: 'uppercase' }}>{label}</div>
              </div>
            ))}
          </div>
        </div>

        <div style={{ background: '#0a1830', position: 'relative', overflow: 'hidden' }}>
          <div style={{ position: 'absolute', top: '-40px', right: '-40px', opacity: 0.18 }}>
            <SpineIcon size={140} color="#a8b8d4" opacity={0.6} />
          </div>
          <div style={{ padding: '60px', height: '100%', display: 'flex', flexDirection: 'column', justifyContent: 'center', position: 'relative', zIndex: 2 }}>
            <div style={{ marginBottom: '32px' }}>
              <div style={{ fontFamily: "'Fraunces', serif", fontSize: '64px', color: '#a8b8d4', lineHeight: 0.5, fontStyle: 'italic' }}>"</div>
              <p style={{ fontFamily: "'Fraunces', serif", fontSize: '22px', fontStyle: 'italic', color: '#fff', lineHeight: 1.45, fontWeight: 300, marginTop: '8px' }}>
                {lang === 'es' ? 'La cirugía debe ser el último recurso, no el primero. Cada paciente merece un plan diseñado para su vida.' : 'Surgery should be the last resort, not the first. Every patient deserves a plan designed for their life.'}
              </p>
            </div>
            <div style={{ display: 'flex', gap: '20px', alignItems: 'center' }}>
              <div style={{ width: '120px', height: '160px', overflow: 'hidden', borderRadius: '4px' }}>
                <DoctorPhoto w={120} h={160} label="" />
              </div>
              <div>
                <div style={{ fontFamily: "'Fraunces', serif", fontSize: '20px', color: '#fff', fontWeight: 400 }}>Dr. Guillermo Julio Tatis</div>
                <div style={{ fontSize: '12px', color: '#a8b8d4', letterSpacing: '0.1em', textTransform: 'uppercase', marginTop: '4px' }}>{lang === 'es' ? 'Cirujano de Columna' : 'Spine Surgeon'}</div>
                <div style={{ marginTop: '10px', display: 'flex', flexDirection: 'column', gap: '4px' }}>
                  {t.credentials.slice(0, 3).map(c => (
                    <div key={c} style={{ fontSize: '11px', color: '#c4d0e4', display: 'flex', gap: '6px' }}>
                      <span style={{ color: '#5a8acc' }}>✓</span> <span>{c}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div style={{ background: '#fff', padding: '24px 56px', borderTop: '1px solid #e4e9f0', borderBottom: '1px solid #e4e9f0', display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: '40px' }}>
        <span style={{ fontSize: '11px', letterSpacing: '0.2em', color: '#5a7090', textTransform: 'uppercase', whiteSpace: 'nowrap' }}>{lang === 'es' ? 'Acreditaciones y miembro de:' : 'Accreditations and member of:'}</span>
        <div style={{ display: 'flex', gap: '32px', flex: 1, justifyContent: 'space-around' }}>
          {['NASS', 'AOSpine', 'Soc. Ortopedia PA', 'COPAC', 'WCO'].map(x => (
            <div key={x} style={{ fontFamily: "'Fraunces', serif", fontSize: '15px', color: '#0a1830', fontWeight: 500, letterSpacing: '0.02em', opacity: 0.65 }}>{x}</div>
          ))}
        </div>
      </div>

      <div style={{ padding: '80px 56px', background: '#f4f6fa' }}>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 2fr', gap: '40px', marginBottom: '48px' }}>
          <div>
            <div style={{ fontSize: '11px', letterSpacing: '0.25em', color: '#1a3a6e', textTransform: 'uppercase', marginBottom: '12px' }}>{lang === 'es' ? 'Áreas de Especialización' : 'Specialty Areas'}</div>
            <div style={{ fontFamily: "'Fraunces', serif", fontSize: '44px', color: '#0a1830', fontWeight: 400, lineHeight: 1.05, letterSpacing: '-0.02em' }}>{lang === 'es' ? 'Tratamientos integrales para tu columna' : 'Comprehensive spine treatments'}</div>
          </div>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '1px', background: '#d4dce8' }}>
          {t.services.map((s, i) => (
            <div key={s.name} style={{ background: '#fff', padding: '36px 32px', cursor: 'pointer' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '20px' }}>
                <div style={{ fontFamily: "'Fraunces', serif", fontSize: '14px', color: '#a8b8d4', letterSpacing: '0.05em' }}>0{i+1}</div>
                <SpineIcon size={28} color="#1a3a6e" opacity={0.4} />
              </div>
              <div style={{ fontFamily: "'Fraunces', serif", fontSize: '22px', color: '#0a1830', fontWeight: 500, marginBottom: '10px', letterSpacing: '-0.01em' }}>{s.name}</div>
              <div style={{ fontSize: '14px', color: '#5a7090', lineHeight: 1.55 }}>{s.desc}</div>
              <div style={{ marginTop: '20px', fontSize: '12px', color: '#1a3a6e', letterSpacing: '0.08em', fontWeight: 600 }}>{lang === 'es' ? 'CONOCER MÁS →' : 'LEARN MORE →'}</div>
            </div>
          ))}
        </div>
      </div>

      <div style={{ padding: '80px 56px', background: '#fff' }}>
        <div style={{ textAlign: 'center', marginBottom: '56px' }}>
          <div style={{ fontSize: '11px', letterSpacing: '0.25em', color: '#1a3a6e', textTransform: 'uppercase', marginBottom: '12px' }}>{t.procTitle}</div>
          <div style={{ fontFamily: "'Fraunces', serif", fontSize: '40px', color: '#0a1830', fontWeight: 400, letterSpacing: '-0.02em' }}>{t.procSub}</div>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '32px' }}>
          {t.proc.map((p, i) => (
            <div key={p.num} style={{ position: 'relative' }}>
              {i < 3 && <div style={{ position: 'absolute', top: '20px', left: 'calc(100% - 16px)', right: '-16px', height: '1px', background: '#d4dce8' }} />}
              <div style={{ width: '40px', height: '40px', borderRadius: '50%', background: '#0a1830', color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: "'Fraunces', serif", fontSize: '14px', marginBottom: '20px' }}>{p.num}</div>
              <div style={{ fontFamily: "'Fraunces', serif", fontSize: '20px', color: '#0a1830', fontWeight: 500, marginBottom: '8px' }}>{p.title}</div>
              <div style={{ fontSize: '13px', color: '#5a7090', lineHeight: 1.55 }}>{p.desc}</div>
            </div>
          ))}
        </div>
      </div>

      <div style={{ padding: '80px 56px', background: '#0a1830', color: '#fff', display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '64px' }}>
        <div>
          <div style={{ fontSize: '11px', letterSpacing: '0.25em', color: '#5a8acc', textTransform: 'uppercase', marginBottom: '12px' }}>{lang === 'es' ? 'Hablemos' : 'Let\'s talk'}</div>
          <h2 style={{ fontFamily: "'Fraunces', serif", fontSize: '52px', color: '#fff', fontWeight: 400, marginBottom: '16px', letterSpacing: '-0.02em', lineHeight: 1.05 }}>{t.contactTitle}</h2>
          <p style={{ fontSize: '15px', color: '#a8b8d4', marginBottom: '32px', lineHeight: 1.6 }}>{t.contactSub}</p>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
            <div style={{ display: 'flex', gap: '12px', alignItems: 'center' }}>
              <div style={{ width: '36px', height: '36px', background: 'rgba(90,138,204,0.15)', borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>📞</div>
              <div>
                <div style={{ fontSize: '11px', color: '#5a8acc', letterSpacing: '0.1em', textTransform: 'uppercase' }}>{lang === 'es' ? 'Llamada directa' : 'Direct call'}</div>
                <div style={{ fontSize: '15px', color: '#fff', marginTop: '2px' }}>+507 6000-0000</div>
              </div>
            </div>
            <div style={{ display: 'flex', gap: '12px', alignItems: 'center' }}>
              <div style={{ width: '36px', height: '36px', background: 'rgba(37,211,102,0.18)', borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>💬</div>
              <div>
                <div style={{ fontSize: '11px', color: '#25D366', letterSpacing: '0.1em', textTransform: 'uppercase' }}>WhatsApp</div>
                <div style={{ fontSize: '15px', color: '#fff', marginTop: '2px' }}>+507 6000-0000</div>
              </div>
            </div>
            <div style={{ display: 'flex', gap: '12px', alignItems: 'center' }}>
              <div style={{ width: '36px', height: '36px', background: 'rgba(90,138,204,0.15)', borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>📍</div>
              <div>
                <div style={{ fontSize: '11px', color: '#5a8acc', letterSpacing: '0.1em', textTransform: 'uppercase' }}>{lang === 'es' ? 'Ubicación' : 'Location'}</div>
                <div style={{ fontSize: '15px', color: '#fff', marginTop: '2px' }}>{t.footerLoc}</div>
              </div>
            </div>
          </div>
        </div>
        <ContactForm lang={lang} dark />
      </div>
    </div>
  );
};

window.ClinicalAuthority = ClinicalAuthority;
