/* ===== VARIANT 3: TRUST & RECOVERY ===== */
const TrustRecovery = ({ lang }) => {
  const t = CONTENT[lang];
  return (
    <div style={{ width: '100%', minHeight: '1450px', background: '#fff', color: '#0a1830', fontFamily: "'DM Sans', sans-serif" }}>
      <nav style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '20px 56px', borderBottom: '1px solid #e8edf3' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '14px' }}>
          <div style={{ width: '40px', height: '40px', background: '#1a3a6e', borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#fff', fontFamily: "'Cormorant Garamond', serif", fontSize: '20px', fontStyle: 'italic' }}>G</div>
          <div>
            <div style={{ fontSize: '15px', color: '#0a1830', fontWeight: 600, letterSpacing: '-0.005em' }}>Dr. Julio Tatis</div>
            <div style={{ fontSize: '10px', letterSpacing: '0.18em', color: '#5a7090', textTransform: 'uppercase' }}>{lang === 'es' ? 'Especialista en Columna' : 'Spine Specialist'}</div>
          </div>
        </div>
        <div style={{ display: 'flex', gap: '32px', alignItems: 'center' }}>
          {t.nav.map(item => <span key={item} style={{ fontSize: '13px', color: '#3a4a6a', cursor: 'pointer' }}>{item}</span>)}
          <button style={{ padding: '10px 20px', background: '#25D366', border: 'none', color: '#fff', fontSize: '12px', fontWeight: 600, cursor: 'pointer', borderRadius: '6px', display: 'flex', alignItems: 'center', gap: '6px' }}>💬 WhatsApp</button>
        </div>
      </nav>

      <div style={{ display: 'grid', gridTemplateColumns: '1.05fr 1fr', minHeight: '620px', background: '#f4f6fa' }}>
        <div style={{ padding: '72px 56px', display: 'flex', flexDirection: 'column', justifyContent: 'center' }}>
          <div style={{ display: 'inline-flex', alignItems: 'center', gap: '8px', marginBottom: '24px', fontSize: '12px', color: '#1a3a6e', fontWeight: 600, letterSpacing: '0.1em' }}>
            <span style={{ width: '24px', height: '1.5px', background: '#1a3a6e' }} />
            <span style={{ textTransform: 'uppercase' }}>{t.badge}</span>
          </div>
          <h1 style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: '78px', lineHeight: 0.97, fontWeight: 400, color: '#0a1830', letterSpacing: '-0.02em', marginBottom: '24px' }}>
            {lang === 'es' ? 'Tu espalda no debería' : 'Your back shouldn\'t'}<br />
            <em style={{ fontStyle: 'italic', color: '#1a3a6e' }}>{lang === 'es' ? 'limitarte' : 'limit you'}.</em>
          </h1>
          <p style={{ fontSize: '17px', lineHeight: 1.65, color: '#3a4a6a', maxWidth: '460px', marginBottom: '32px' }}>
            {lang === 'es' ? 'Recupera la libertad de moverte. Cirugía mínimamente invasiva, técnicas de vanguardia, atención humana real.' : 'Reclaim the freedom to move. Minimally invasive surgery, cutting-edge techniques, genuinely human care.'}
          </p>

          <div style={{ background: '#fff', padding: '20px 24px', borderLeft: '3px solid #1a3a6e', marginBottom: '32px', maxWidth: '460px' }}>
            <div style={{ fontSize: '11px', color: '#1a3a6e', letterSpacing: '0.15em', textTransform: 'uppercase', fontWeight: 600, marginBottom: '12px' }}>{lang === 'es' ? '¿Te sientes identificado?' : 'Sound familiar?'}</div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
              {(lang === 'es' ? ['Dolor lumbar persistente que afecta tu día a día', 'Hormigueo o adormecimiento en piernas o brazos', 'Diagnósticos contradictorios y sin solución clara'] : ['Persistent low back pain affecting daily life', 'Tingling or numbness in legs or arms', 'Conflicting diagnoses with no clear solution']).map(c => (
                <div key={c} style={{ display: 'flex', gap: '10px', alignItems: 'flex-start', fontSize: '14px', color: '#3a4a6a' }}>
                  <span style={{ color: '#1a3a6e', marginTop: '2px' }}>✓</span> <span>{c}</span>
                </div>
              ))}
            </div>
          </div>

          <div style={{ display: 'flex', gap: '12px' }}>
            <button style={{ padding: '17px 30px', background: '#25D366', border: 'none', color: '#fff', fontSize: '14px', fontWeight: 600, cursor: 'pointer', borderRadius: '6px', display: 'flex', alignItems: 'center', gap: '10px', boxShadow: '0 6px 20px -4px rgba(37,211,102,0.4)' }}>
              <svg width="18" height="18" viewBox="0 0 24 24" fill="#fff"><path d="M17.6 6.3A7.85 7.85 0 0 0 12 4a7.94 7.94 0 0 0-7.9 7.9 7.83 7.83 0 0 0 1 3.9L4 20l4.3-1.1a7.93 7.93 0 0 0 3.7.9 7.94 7.94 0 0 0 7.9-7.9 7.85 7.85 0 0 0-2.3-5.6Z"/></svg>
              {t.ctaWhats}
            </button>
            <button style={{ padding: '17px 24px', background: '#fff', border: '1px solid #d4dce8', color: '#0a1830', fontSize: '14px', fontWeight: 500, cursor: 'pointer', borderRadius: '6px' }}>📅 {lang === 'es' ? 'Pedir cita online' : 'Book online'}</button>
          </div>
        </div>

        <div style={{ position: 'relative', overflow: 'hidden' }}>
          <ClinicPhoto w={640} h={620} variant="spine" label={lang === 'es' ? 'Dr. en consulta · COPAC' : 'Dr. in consultation · COPAC'} />
          <div style={{ position: 'absolute', bottom: '32px', left: '32px', right: '32px', background: 'rgba(10,24,48,0.93)', backdropFilter: 'blur(10px)', color: '#fff', padding: '24px', borderRadius: '8px', display: 'flex', gap: '20px', alignItems: 'center' }}>
            <div style={{ width: '64px', height: '64px', borderRadius: '50%', overflow: 'hidden', flexShrink: 0 }}>
              <DoctorPhoto w={64} h={64} label="" />
            </div>
            <div style={{ flex: 1 }}>
              <div style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: '20px', fontWeight: 500 }}>Dr. Guillermo Julio Tatis</div>
              <div style={{ fontSize: '12px', color: '#a8b8d4', marginTop: '2px' }}>{lang === 'es' ? 'Maestría Internacional · 15+ años' : 'Int\'l Master\'s · 15+ years'}</div>
              <div style={{ display: 'flex', gap: '4px', marginTop: '8px' }}>
                {[1,2,3,4,5].map(s => <span key={s} style={{ color: '#f5b400', fontSize: '13px' }}>★</span>)}
                <span style={{ fontSize: '12px', color: '#fff', fontWeight: 600, marginLeft: '6px' }}>4.9 · 320 {lang === 'es' ? 'reseñas' : 'reviews'}</span>
              </div>
            </div>
            <button style={{ background: '#25D366', border: 'none', color: '#fff', padding: '12px 18px', fontSize: '12px', fontWeight: 600, cursor: 'pointer', borderRadius: '6px' }}>{lang === 'es' ? 'Contactar' : 'Contact'} →</button>
          </div>
        </div>
      </div>

      <div style={{ padding: '40px 56px', background: '#fff', borderBottom: '1px solid #e8edf3' }}>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '32px', alignItems: 'center' }}>
          {[['1,500+', t.statsLabels[0]], ['15+', t.statsLabels[1]], ['98%', t.statsLabels[2]], ['80%', lang === 'es' ? 'Sin cirugía' : 'Without surgery']].map(([num, label], i) => (
            <div key={label} style={{ textAlign: 'center', borderRight: i < 3 ? '1px solid #e8edf3' : 'none' }}>
              <div style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: '44px', color: '#1a3a6e', fontWeight: 400, lineHeight: 1 }}>{num}</div>
              <div style={{ fontSize: '11px', color: '#5a7090', letterSpacing: '0.12em', marginTop: '6px', textTransform: 'uppercase' }}>{label}</div>
            </div>
          ))}
        </div>
      </div>

      <div style={{ padding: '80px 56px', background: '#fff' }}>
        <div style={{ marginBottom: '48px', maxWidth: '720px' }}>
          <div style={{ fontSize: '11px', letterSpacing: '0.22em', color: '#1a3a6e', textTransform: 'uppercase', marginBottom: '12px', fontWeight: 600 }}>{lang === 'es' ? 'Servicios' : 'Services'}</div>
          <h2 style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: '52px', color: '#0a1830', fontWeight: 400, letterSpacing: '-0.02em', lineHeight: 1.05, marginBottom: '16px' }}>{lang === 'es' ? 'Tratamientos especializados, atención personal' : 'Specialized treatments, personal care'}</h2>
          <p style={{ fontSize: '16px', color: '#5a7090', lineHeight: 1.6 }}>{lang === 'es' ? 'Cada caso es único. Por eso evaluamos a profundidad antes de proponer un plan de tratamiento.' : 'Every case is unique. We evaluate in depth before proposing a treatment plan.'}</p>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '24px' }}>
          {t.services.map((s, i) => (
            <div key={s.name} style={{ background: '#fff', border: '1px solid #e8edf3', cursor: 'pointer', overflow: 'hidden', transition: 'all 0.2s' }}>
              <ClinicPhoto w={400} h={140} variant={i % 2 === 0 ? 'spine' : 'portrait'} label={s.name} />
              <div style={{ padding: '24px' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '10px' }}>
                  <div style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: '22px', color: '#0a1830', fontWeight: 500 }}>{s.name}</div>
                  <div style={{ fontSize: '11px', color: '#a8b8d4', letterSpacing: '0.05em' }}>0{i+1}/06</div>
                </div>
                <div style={{ fontSize: '13px', color: '#5a7090', lineHeight: 1.55, marginBottom: '16px' }}>{s.desc}</div>
                <div style={{ fontSize: '12px', color: '#1a3a6e', fontWeight: 600, letterSpacing: '0.05em' }}>{lang === 'es' ? 'AGENDAR EVALUACIÓN →' : 'BOOK EVALUATION →'}</div>
              </div>
            </div>
          ))}
        </div>
      </div>

      <div style={{ padding: '80px 56px', background: '#f4f6fa' }}>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 2fr', gap: '40px' }}>
          <div>
            <div style={{ fontSize: '11px', letterSpacing: '0.22em', color: '#1a3a6e', textTransform: 'uppercase', marginBottom: '12px', fontWeight: 600 }}>{lang === 'es' ? 'Historias reales' : 'Real stories'}</div>
            <h2 style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: '44px', color: '#0a1830', fontWeight: 400, letterSpacing: '-0.02em', lineHeight: 1.05, marginBottom: '20px' }}>{t.testimonialTitle}</h2>
            <p style={{ fontSize: '14px', color: '#5a7090', lineHeight: 1.6, marginBottom: '24px' }}>{lang === 'es' ? 'Más de 1,500 pacientes han recuperado su movilidad. Estas son algunas de sus historias.' : 'Over 1,500 patients have regained their mobility. Here are some of their stories.'}</p>
            <div style={{ display: 'flex', gap: '12px' }}>
              <button style={{ width: '40px', height: '40px', border: '1px solid #d4dce8', background: '#fff', cursor: 'pointer', borderRadius: '50%' }}>←</button>
              <button style={{ width: '40px', height: '40px', border: '1px solid #1a3a6e', background: '#1a3a6e', color: '#fff', cursor: 'pointer', borderRadius: '50%' }}>→</button>
            </div>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: '16px' }}>
            {t.testimonials.slice(0, 2).map(tt => (
              <div key={tt.name} style={{ background: '#fff', padding: '28px', border: '1px solid #e8edf3' }}>
                <div style={{ display: 'flex', gap: '4px', marginBottom: '14px' }}>
                  {[1,2,3,4,5].map(s => <span key={s} style={{ color: '#f5b400', fontSize: '14px' }}>★</span>)}
                </div>
                <p style={{ fontFamily: "'Cormorant Garamond', serif", fontStyle: 'italic', fontSize: '17px', color: '#0a1830', lineHeight: 1.5, marginBottom: '20px' }}>"{tt.text}"</p>
                <div style={{ display: 'flex', gap: '12px', alignItems: 'center', paddingTop: '16px', borderTop: '1px solid #e8edf3' }}>
                  <div style={{ width: '40px', height: '40px', borderRadius: '50%', background: '#e8edf3', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#1a3a6e', fontWeight: 600 }}>{tt.name.charAt(0)}</div>
                  <div>
                    <div style={{ fontSize: '13px', color: '#0a1830', fontWeight: 600 }}>{tt.name}</div>
                    <div style={{ fontSize: '11px', color: '#5a7090', marginTop: '2px' }}>{tt.context}</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div style={{ padding: '80px 56px', background: '#fff' }}>
        <div style={{ textAlign: 'center', marginBottom: '48px', maxWidth: '720px', margin: '0 auto 48px' }}>
          <div style={{ fontSize: '11px', letterSpacing: '0.22em', color: '#1a3a6e', textTransform: 'uppercase', marginBottom: '12px', fontWeight: 600 }}>{lang === 'es' ? 'Tu camino' : 'Your journey'}</div>
          <h2 style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: '44px', color: '#0a1830', fontWeight: 400, letterSpacing: '-0.02em', lineHeight: 1.05 }}>{t.procSub}</h2>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '0px' }}>
          {t.proc.map((p, i) => (
            <div key={p.num} style={{ padding: '28px', borderRight: i < 3 ? '1px dashed #d4dce8' : 'none', textAlign: 'center' }}>
              <div style={{ width: '56px', height: '56px', borderRadius: '50%', background: '#eef2f8', color: '#1a3a6e', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 16px', fontFamily: "'Cormorant Garamond', serif", fontSize: '22px', fontWeight: 500 }}>{p.num}</div>
              <div style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: '20px', color: '#0a1830', fontWeight: 500, marginBottom: '8px' }}>{p.title}</div>
              <div style={{ fontSize: '13px', color: '#5a7090', lineHeight: 1.55 }}>{p.desc}</div>
            </div>
          ))}
        </div>
      </div>

      <div style={{ padding: '64px 56px', background: 'linear-gradient(135deg, #0a1830 0%, #1a3a6e 100%)', color: '#fff' }}>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '64px', alignItems: 'center' }}>
          <div>
            <h2 style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: '52px', fontWeight: 400, letterSpacing: '-0.02em', lineHeight: 1.05, marginBottom: '20px' }}>{lang === 'es' ? 'Da el primer paso hoy' : 'Take the first step today'}</h2>
            <p style={{ fontSize: '16px', color: '#a8b8d4', lineHeight: 1.6, marginBottom: '32px' }}>{lang === 'es' ? 'Una consulta puede cambiar tu vida. Respondemos por WhatsApp en menos de 1 hora hábil.' : 'One consultation can change your life. We reply on WhatsApp within 1 business hour.'}</p>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
              {[
                ['📞', '+507 6000-0000', lang === 'es' ? 'Llamada directa' : 'Direct call'],
                ['💬', '+507 6000-0000', 'WhatsApp'],
                ['📍', t.footerLoc, lang === 'es' ? 'Ubicación' : 'Location'],
                ['🕐', t.footerHours, lang === 'es' ? 'Horario' : 'Hours'],
              ].map(([icon, val, lab]) => (
                <div key={lab} style={{ display: 'flex', gap: '14px', alignItems: 'center' }}>
                  <div style={{ width: '40px', height: '40px', background: 'rgba(255,255,255,0.08)', borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>{icon}</div>
                  <div>
                    <div style={{ fontSize: '15px', color: '#fff', fontWeight: 500 }}>{val}</div>
                    <div style={{ fontSize: '11px', color: '#a8b8d4', letterSpacing: '0.08em' }}>{lab}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
          <ContactForm lang={lang} dark />
        </div>
      </div>
    </div>
  );
};

window.TrustRecovery = TrustRecovery;
